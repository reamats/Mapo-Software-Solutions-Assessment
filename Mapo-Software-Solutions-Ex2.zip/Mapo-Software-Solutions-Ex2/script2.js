
fetch("TCO.json")
.then(function(response){
	return response.json();
})
.then(function(results){
	let placeholder = document.querySelector("#CostPerKm");
	let out = "";
	var  sumVal = 0;
	var roundedSumVal=0;
   
	for(let result of results){

		sumVal= result.serviceCostPerKm + result.maintenanceAdditionalCostPerKm + result.maintenanceAdditionalCostPerKm + result.tyreCostPerKm +
		        result.fuelCostPerKm + result.residualValuePerKm + result.depreciationPerKm + result.financeCostPerKm + result.financeCostBasePerKm +
				result.financeCostInterestPerKm + result.insuranceCostPerKm;
		out += `
			<tr>
				<td>${result.country} </td>
				<td>${result.lifeTime}</td>
				<td>${result.serviceCostPerKm}</td>
                <td>${result.maintenanceCostPerKm}</td>
				<td>${result.maintenanceAdditionalCostPerKm}</td>
				<td>${result.tyreCostPerKm}</td>
				<td>${result.fuelCostPerKm}</td>
				<td>${result.residualValuePerKm}</td>
				<td>${result.depreciationPerKm}</td>
				<td>${result.financeCostPerKm}</td>
				<td>${result.financeCostBasePerKm}</td>
				<td>${result.financeCostInterestPerKm}</td>
				<td>${result.insuranceCostPerKm}</td>
				<td>${sumVal}</td>
			</tr>
		`;
	}

	let placeholder2 = document.querySelector("#Cost");
	let tab = "";

	var total =0;
	var roundedTotal=0;
	for(let result of results){

		total= result.serviceCost + result.maintenanceAdditionalCost + result.maintenanceAdditionalCost + result.tyreCost +
		        result.fuelCost + result.residualValue + result.depreciationValue + result.financeCost + result.financeCostBase +
				result.financeCostInterest + result.insuranceCost; 

        roundedTotal= total.toFixed(2);
		tab += `
			<tr>
				<td>${result.country} </td>
				<td>${result.lifeTime}</td>
				<td>${result.serviceCost}</td>
                <td>${result.maintenanceCost}</td>
				<td>${result.maintenanceAdditionalCost}</td>
				<td>${result.tyreCost}</td>
				<td>${result.fuelCost}</td>
				<td>${result.residualValue}</td>
				<td>${result.depreciationValue}</td>
				<td>${result.financeCost}</td>
				<td>${result.financeCostBase}</td>
				<td>${result.financeCostInterest}</td>
				<td>${result.insuranceCost}</td>
				<td>${roundedTotal}</td>
			</tr>
		`;
	}


	placeholder.innerHTML = out;
	placeholder2.innerHTML = tab;
});