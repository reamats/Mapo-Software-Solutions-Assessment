fetch("https://za-api.mapo-int.com/swagger/index.html/api/ServicePlan/Totals", {
    headers:{Authentication:' 055cebf52a0ac15'}
}) 
.then(resp => resp.json())
.then(json => console.log(JSON.stringify(json)))
.then(function(services){
    let placeholder = document.querySelector("#data-output");
    let out = "";
    for(let service of services){
       out += `
          <tr>
             <td> ${service.Interval} </td>
             <td>${service.Parts}</td>
             <td>${service.Fluids}</td>
             <td>${service.Labour}</td>
             <td>${service.Sundries}</td>
             <td>${service.Total}</td>
          </tr>
       `;
    }
    placeholder.innerHTML = out;
});