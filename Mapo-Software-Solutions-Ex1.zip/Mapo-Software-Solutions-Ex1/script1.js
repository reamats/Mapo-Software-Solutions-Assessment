var xmlhttp= new XMLHttpRequest();
var url = "http://localhost/Mapo-Software-Solutions-Ex1/SERVICETOTALS.json";
xmlhttp.open("GET",url,true);
xmlhttp.send();
xmlhttp.onreadystatechange= function() {

  if(this.readyState == 4 && this.status==200){
    var data= JSON.parse(this.responseText);
    
    interval= data.result.servicePlans.map(function(elem){
      return elem.interval;
      
    })
    total= data.result.servicePlans.map(function(elem){
      return elem.total;
    })
    //console.log(total)

    const ctx = document.getElementById('canvas');

  new Chart(ctx, {
    type: 'bar',
    data: {
      labels:interval,
      datasets: [{
        label: 'Service Plan (Total Per Interval)',
        data: total,
        backgroundColor:"#BC8F8F",
        borderWidth: 2
      }]
    },
    options: {
      scales: {
        y: {
          beginAtZero: true
        }
      }
    }
  });
  }

}

